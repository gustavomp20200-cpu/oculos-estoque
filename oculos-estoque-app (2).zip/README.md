# Estoque de Óculos (Vite + React + Tailwind)

Dois estoques (Para Fazer / Prontos), saídas/retornos de vendedor, vendas com valores, média semanal por grau e semanas de cobertura.

## Rodar localmente
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
npm run preview
```

## Publicar na Vercel
1. Crie um repositório no GitHub e suba estes arquivos.
2. Acesse https://vercel.com , importe o repositório e clique **Deploy**.
3. Framework: `Vite` (detecta automático). Node 18+.
