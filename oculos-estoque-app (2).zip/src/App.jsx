
import React, { useEffect, useMemo, useState } from "react";

const GRAUS = ["0.5","1.0","1.5","2.0","2.5","3.0","3.5","4.0","SOL"];
const emptyStockByGrau = () => Object.fromEntries(GRAUS.map(g => [g, { paraFazer: 0, prontos: 0 }]));

const LS_KEYS = {
  STOCK: "oculos.stock.v1",
  SALES: "oculos.sales.v1",
  VENDOR_TRIPS: "oculos.trips.v1",
  AVG_HINT: "oculos.avgHint.v1"
};

const SEED_FROM_SHEET = [
  { grau: "0.5", para_fazer: 0, prontos: 500, total: 500, media_semanal: 125.0 },
  { grau: "1.0", para_fazer: 0, prontos: 1780, total: 1780, media_semanal: 525.0 },
  { grau: "1.5", para_fazer: 1470, prontos: 5660, total: 7130, media_semanal: 710.0 },
  { grau: "2.0", para_fazer: 630, prontos: 5160, total: 5790, media_semanal: 960.0 },
  { grau: "2.5", para_fazer: 4410, prontos: 4070, total: 8480, media_semanal: 990.0 },
  { grau: "3.0", para_fazer: 1570, prontos: 5040, total: 6610, media_semanal: 715.0 },
  { grau: "3.5", para_fazer: 960, prontos: 2310, total: 3270, media_semanal: 585.0 },
  { grau: "4.0", para_fazer: 0, prontos: 790, total: 790, media_semanal: 160.0 },
  { grau: "SOL", para_fazer: 700, prontos: 530, total: 1230, media_semanal: 702.5 },
];

const round2 = (n) => Math.round((Number(n)||0)*100)/100;
const weeksBetween = (d1, d2) => Math.abs(new Date(d2) - new Date(d1)) / (7*24*60*60*1000);
const todayISO = () => new Date().toISOString();

export default function App(){
  const [tab, setTab] = useState("dashboard");

  const [stock, setStock] = useState(()=>{
    const raw = localStorage.getItem(LS_KEYS.STOCK);
    if(raw){ try { return JSON.parse(raw); } catch{} }
    const init = emptyStockByGrau();
    SEED_FROM_SHEET.forEach(r => { init[r.grau] = { paraFazer: Number(r.para_fazer)||0, prontos: Number(r.prontos)||0 }; });
    return init;
  });

  const [sales, setSales] = useState(()=>{
    const raw = localStorage.getItem(LS_KEYS.SALES);
    if(raw){ try { return JSON.parse(raw); } catch{} }
    return [];
  });

  const [trips, setTrips] = useState(()=>{
    const raw = localStorage.getItem(LS_KEYS.VENDOR_TRIPS);
    if(raw){ try { return JSON.parse(raw); } catch{} }
    return [];
  });

  const [avgHint, setAvgHint] = useState(()=>{
    const raw = localStorage.getItem(LS_KEYS.AVG_HINT);
    if(raw){ try { return JSON.parse(raw); } catch{} }
    return Object.fromEntries(SEED_FROM_SHEET.map(r => [r.grau, r.media_semanal]));
  });

  useEffect(()=>{ localStorage.setItem(LS_KEYS.STOCK, JSON.stringify(stock)); },[stock]);
  useEffect(()=>{ localStorage.setItem(LS_KEYS.SALES, JSON.stringify(sales)); },[sales]);
  useEffect(()=>{ localStorage.setItem(LS_KEYS.VENDOR_TRIPS, JSON.stringify(trips)); },[trips]);
  useEffect(()=>{ localStorage.setItem(LS_KEYS.AVG_HINT, JSON.stringify(avgHint)); },[avgHint]);

  const { weeklyAvgByGrau, weeksOfCoverTotal, weeksOfCoverProntos } = useMemo(() => {
    const now = new Date();
    const fourWeeksAgo = new Date(now.getTime() - 28*24*60*60*1000);
    const recent = sales.filter(s => new Date(s.date) >= fourWeeksAgo);
    const sum = Object.fromEntries(GRAUS.map(g => [g, 0]));
    recent.forEach(s => { sum[s.grau] += Number(s.vendido)||0; });
    const weeks = Math.max(weeksBetween(fourWeeksAgo, now), 0.0001);
    const avg = Object.fromEntries(GRAUS.map(g => [g, round2(sum[g] / weeks)]));
    GRAUS.forEach(g => { if((avg[g]||0) === 0 && (avgHint[g]||0) > 0) avg[g] = Number(avgHint[g]); });
    const wocTotal = Object.fromEntries(GRAUS.map(g => {
      const total = (stock[g]?.paraFazer||0) + (stock[g]?.prontos||0);
      const a = avg[g]||0; return [g, a>0 ? round2(total / a) : null];
    }));
    const wocReady = Object.fromEntries(GRAUS.map(g => {
      const ready = (stock[g]?.prontos||0);
      const a = avg[g]||0; return [g, a>0 ? round2(ready / a) : null];
    }));
    return { weeklyAvgByGrau: avg, weeksOfCoverTotal: wocTotal, weeksOfCoverProntos: wocReady };
  }, [sales, stock, avgHint]);

  function entradaFornecedor(grau, quantidade){
    setStock(prev => ({ ...prev, [grau]: { ...prev[grau], paraFazer: (prev[grau]?.paraFazer||0) + Number(quantidade||0) } }));
  }

  function processarParaPronto(grau, quantidade){
    setStock(prev => {
      const pf = Math.max((prev[grau]?.paraFazer||0) - Number(quantidade||0), 0);
      const pr = (prev[grau]?.prontos||0) + Math.min(Number(quantidade||0), (prev[grau]?.paraFazer||0));
      return { ...prev, [grau]: { paraFazer: pf, prontos: pr } };
    });
  }

  function criarViagem(vendedor, itens){
    // desconta de PRONTOS
    setStock(prev => {
      const next = { ...prev };
      for(const g of Object.keys(itens)){
        const q = Number(itens[g]||0);
        next[g] = next[g] || { paraFazer:0, prontos:0 };
        next[g].prontos = Math.max(0, (next[g].prontos||0) - q);
      }
      return next;
    });
    const id = crypto.randomUUID();
    const trip = { id, vendedor, dateOut: todayISO(), items: itens, returned: {}, sold: {}, valores: {} };
    setTrips(prev => [trip, ...prev]);
    return id;
  }

  function finalizarViagem(id, devolvidos, vendidos, valores){
    // devolvidos voltam para PRONTOS; vendidos viram histórico
    setStock(prev => {
      const next = { ...prev };
      for(const g of GRAUS){
        const d = Number(devolvidos[g]||0);
        if(d>0){
          next[g] = next[g] || { paraFazer:0, prontos:0 };
          next[g].prontos = (next[g].prontos||0) + d;
        }
      }
      return next;
    });
    const trip = trips.find(t => t.id === id);
    const vendedor = trip?.vendedor || "";
    const vendasLinhas = [];
    for(const g of GRAUS){
      const vend = Number(vendidos[g]||0);
      const val = Number(valores[g]||0);
      if(vend>0){ vendasLinhas.push({ date: todayISO(), vendedor, grau: g, vendido: vend, valorTotal: val }); }
    }
    if(vendasLinhas.length){ setSales(prev => [...vendasLinhas, ...prev]); }
    setTrips(prev => prev.map(t => t.id === id ? { ...t, returned: devolvidos, sold: vendidos, valores, dateBack: todayISO() } : t));
  }

  function Section({title, children, right}){
    return (
      <div className="card">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-lg font-semibold">{title}</h3>
          {right}
        </div>
        {children}
      </div>
    );
  }

  function Dashboard(){
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {GRAUS.map(g => {
          const pf = stock[g]?.paraFazer||0; const pr = stock[g]?.prontos||0; const tot = pf+pr;
          const avg = weeklyAvgByGrau[g]||0; const wocT = weeksOfCoverTotal[g]; const wocP = weeksOfCoverProntos[g];
          return (
            <div key={g} className="card">
              <div className="flex items-center justify-between">
                <h4 className="text-xl font-semibold">Grau {g}</h4>
                <span className="badge">média semanal</span>
              </div>
              <div className="text-2xl font-bold mt-1">{avg ? avg : "–"}</div>
              <div className="grid grid-cols-3 gap-3 mt-3">
                <div className="card-muted">
                  <div className="text-xs opacity-60">Para fazer</div>
                  <div className="text-lg font-semibold">{pf}</div>
                </div>
                <div className="card-muted">
                  <div className="text-xs opacity-60">Prontos</div>
                  <div className="text-lg font-semibold">{pr}</div>
                </div>
                <div className="card-muted">
                  <div className="text-xs opacity-60">Total</div>
                  <div className="text-lg font-semibold">{tot}</div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3 mt-3">
                <div className="card-muted">
                  <div className="text-xs opacity-60">Semanas (Total)</div>
                  <div className="text-lg font-semibold">{wocT ?? "–"}</div>
                </div>
                <div className="card-muted">
                  <div className="text-xs opacity-60">Semanas (Prontos)</div>
                  <div className="text-lg font-semibold">{wocP ?? "–"}</div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    );
  }

  function Entrada(){
    const [grau, setGrau] = useState("1.0");
    const [qtd, setQtd] = useState(0);
    return (
      <Section title="Entrada de mercadoria (fornecedor → Para Fazer)">
        <div className="flex flex-wrap items-end gap-3">
          <div className="w-28">
            <div className="text-sm mb-1">Grau</div>
            <select className="select" value={grau} onChange={e=>setGrau(e.target.value)}>
              {GRAUS.map(g => <option key={g} value={g}>{g}</option>)}
            </select>
          </div>
          <div className="w-40">
            <div className="text-sm mb-1">Quantidade</div>
            <input type="number" className="input" value={qtd} onChange={e=>setQtd(Number(e.target.value||0))} />
          </div>
          <button className="btn" onClick={()=>{ entradaFornecedor(grau, qtd); setQtd(0); }}>Dar entrada</button>
        </div>
      </Section>
    );
  }

  function Processo(){
    const [grau, setGrau] = useState("1.0");
    const [qtd, setQtd] = useState(0);
    const pf = stock[grau]?.paraFazer||0;
    return (
      <Section title="Gravação & Embalagem (Para Fazer → Prontos)">
        <div className="flex flex-wrap items-end gap-3">
          <div className="w-28">
            <div className="text-sm mb-1">Grau</div>
            <select className="select" value={grau} onChange={e=>setGrau(e.target.value)}>
              {GRAUS.map(g => <option key={g} value={g}>{g}</option>)}
            </select>
          </div>
          <div className="w-40">
            <div className="text-sm mb-1">Quantidade (máx {pf})</div>
            <input type="number" className="input" value={qtd} onChange={e=>setQtd(Number(e.target.value||0))} />
          </div>
          <button className="btn" onClick={()=>{ processarParaPronto(grau, Math.min(qtd, pf)); setQtd(0); }}>Processar</button>
        </div>
      </Section>
    );
  }

  function SaidaVendedor(){
    const [vendedor, setVendedor] = useState("");
    const [itens, setItens] = useState(Object.fromEntries(GRAUS.map(g => [g, 0])));

    function criar(){
      if(!vendedor) return alert("Informe o vendedor.");
      const temQtd = Object.values(itens).some(v => (Number(v)||0) > 0);
      if(!temQtd) return alert("Informe pelo menos uma quantidade.");
      const id = criarViagem(vendedor, itens);
      setVendedor("");
      setItens(Object.fromEntries(GRAUS.map(g => [g, 0])));
      alert("Saída registrada. ID da viagem: "+id);
    }

    return (
      <Section title="Saída com vendedor (desconta PRONTOS imediatamente)">
        <div className="flex flex-wrap items-end gap-3 mb-3">
          <div className="w-60">
            <div className="text-sm mb-1">Vendedor</div>
            <input className="input" value={vendedor} onChange={e=>setVendedor(e.target.value)} placeholder="Nome" />
          </div>
          <button className="btn-outline" onClick={criar}>Registrar saída</button>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {GRAUS.map(g => (
            <div key={g} className="card-muted">
              <div className="text-sm font-medium">Grau {g}</div>
              <input type="number" className="input mt-1" value={itens[g]}
                onChange={e=>setItens(prev=>({ ...prev, [g]: Math.max(0, Math.floor(Number(e.target.value||0))) }))} />
              <div className="text-xs opacity-60 mt-1">Prontos disponíveis: {stock[g]?.prontos||0}</div>
            </div>
          ))}
        </div>
      </Section>
    );
  }

  function RetornoVendedor(){
    const abertas = trips.filter(t => !t.dateBack);
    const [tripId, setTripId] = useState("");
    const [devolvidos, setDevolvidos] = useState(Object.fromEntries(GRAUS.map(g => [g, 0])));
    const [vendidos, setVendidos] = useState(Object.fromEntries(GRAUS.map(g => [g, 0])));
    const [valores, setValores] = useState(Object.fromEntries(GRAUS.map(g => [g, 0])));

    function finalizar(){
      if(!tripId) return alert("Selecione a viagem.");
      finalizarViagem(tripId, devolvidos, vendidos, valores);
      setTripId("");
      setDevolvidos(Object.fromEntries(GRAUS.map(g => [g, 0])));
      setVendidos(Object.fromEntries(GRAUS.map(g => [g, 0])));
      setValores(Object.fromEntries(GRAUS.map(g => [g, 0])));
      alert("Retorno registrado com sucesso.");
    }

    return (
      <Section title="Retorno do vendedor (vendas + devoluções para PRONTOS)">
        <div className="flex flex-wrap items-end gap-3 mb-3">
          <div className="w-72">
            <div className="text-sm mb-1">Viagem aberta</div>
            <select className="select" value={tripId} onChange={e=>setTripId(e.target.value)}>
              <option value="">Selecione</option>
              {abertas.map(t => (
                <option key={t.id} value={t.id}>
                  {t.vendedor} • {new Date(t.dateOut).toLocaleString()} • #{t.id.slice(0,6)}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="card-muted">
            <div className="font-medium mb-2">Devolvidos (voltam para PRONTOS)</div>
            <div className="grid grid-cols-3 gap-3">
              {GRAUS.map(g => (
                <div key={g}>
                  <div className="text-xs">{g}</div>
                  <input type="number" className="input" value={devolvidos[g]} onChange={e=>setDevolvidos(prev=>({ ...prev, [g]: Math.max(0, Math.floor(Number(e.target.value||0))) }))}/>
                </div>
              ))}
            </div>
          </div>
          <div className="card-muted">
            <div className="font-medium mb-2">Vendidos & valores</div>
            <div className="grid grid-cols-3 gap-3">
              {GRAUS.map(g => (
                <div key={g}>
                  <div className="text-xs">{g}</div>
                  <input type="number" className="input" value={vendidos[g]} onChange={e=>setVendidos(prev=>({ ...prev, [g]: Math.max(0, Math.floor(Number(e.target.value||0))) }))}/>
                  <input type="number" step="0.01" className="input mt-1" placeholder="R$ valor"
                    value={valores[g]} onChange={e=>setValores(prev=>({ ...prev, [g]: Number(e.target.value||0) }))}/>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="flex justify-end mt-3">
          <button className="btn" onClick={finalizar}>Finalizar retorno</button>
        </div>
      </Section>
    );
  }

  function Relatorios(){
    const resumo = GRAUS.map(g => {
      const pf = stock[g]?.paraFazer||0; const pr = stock[g]?.prontos||0; const tot = pf+pr;
      const avg = weeklyAvgByGrau[g]||0; const wocT = weeksOfCoverTotal[g]; const wocP = weeksOfCoverProntos[g];
      const vendidas = sales.filter(s => s.grau===g);
      const qt = vendidas.reduce((a,b)=>a + Number(b.vendido||0), 0);
      const val = vendidas.reduce((a,b)=>a + Number(b.valorTotal||0), 0);
      return { grau: g, paraFazer: pf, prontos: pr, total: tot, mediaSemanal: avg, semanasTotal: wocT, semanasProntos: wocP, vendidas: qt, faturamento: val };
    });

    return (
      <div className="space-y-4">
        <div className="card">
          <div className="font-semibold mb-2">Resumo por grau</div>
          <div className="overflow-auto">
            <table className="table">
              <thead>
                <tr>
                  <th>Grau</th><th>Para Fazer</th><th>Prontos</th><th>Total</th>
                  <th>Média Semanal</th><th>Semanas (Total)</th><th>Semanas (Prontos)</th>
                  <th>Vendidas</th><th>Faturamento (R$)</th>
                </tr>
              </thead>
              <tbody>
                {resumo.map(r => (
                  <tr key={r.grau} className="border-t">
                    <td className="font-medium">{r.grau}</td>
                    <td>{r.paraFazer}</td>
                    <td>{r.prontos}</td>
                    <td>{r.total}</td>
                    <td>{r.mediaSemanal || "–"}</td>
                    <td>{r.semanasTotal ?? "–"}</td>
                    <td>{r.semanasProntos ?? "–"}</td>
                    <td>{r.vendidas}</td>
                    <td>{r.faturamento.toLocaleString("pt-BR",{minimumFractionDigits:2})}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="card">
          <div className="font-semibold mb-2">Histórico de viagens</div>
          <div className="overflow-auto">
            <table className="table">
              <thead>
                <tr>
                  <th>Data Saída</th><th>Vendedor</th><th>ID</th><th>Data Retorno</th><th>Resumo</th>
                </tr>
              </thead>
              <tbody>
                {trips.map(t => (
                  <tr key={t.id} className="border-t">
                    <td>{new Date(t.dateOut).toLocaleString()}</td>
                    <td>{t.vendedor}</td>
                    <td>#{t.id.slice(0,8)}</td>
                    <td>{t.dateBack ? new Date(t.dateBack).toLocaleString() : "—"}</td>
                    <td>
                      <div className="text-xs opacity-70">
                        Itens: {Object.entries(t.items||{}).filter(([,q])=>q>0).map(([g,q])=>`${g}:${q}`).join(", ") || "—"}
                      </div>
                      {(t.sold && Object.values(t.sold).some(v=>v>0)) && (
                        <div className="text-xs">
                          Vendidos: {Object.entries(t.sold).filter(([,q])=>q>0).map(([g,q])=>`${g}:${q}`).join(", ")}
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }

  function exportJSON(){
    const payload = { stock, sales, trips, avgHint };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = \`estoque-oculos-\${new Date().toISOString().slice(0,10)}.json\`; a.click();
    URL.revokeObjectURL(url);
  }

  function importJSON(file){
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(String(reader.result||"{}"));
        if(data.stock) setStock(data.stock);
        if(data.sales) setSales(data.sales);
        if(data.trips) setTrips(data.trips);
        if(data.avgHint) setAvgHint(data.avgHint);
      } catch(err){ alert("Arquivo inválido.\\n"+err); }
    };
    reader.readAsText(file);
  }

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Estoque de Óculos • Dois estoques + Controle de Vendas</h1>
          <p className="text-sm opacity-70">Grau 0,5 até 4,0 (+ SOL). Entrada → Processamento → Saída do vendedor → Retorno & vendas.</p>
        </div>
        <div className="flex gap-2">
          <label className="btn-outline cursor-pointer">
            <input type="file" accept="application/json" className="hidden"
              onChange={e=>{ const f=e.target.files?.[0]; if(f) importJSON(f); }} />
            Importar
          </label>
          <button className="btn" onClick={exportJSON}>Exportar</button>
        </div>
      </div>

      <div className="card">
        <div className="flex gap-2 flex-wrap">
          <button className={"btn-outline " + (tab==="dashboard" ? "bg-gray-100" : "")} onClick={()=>setTab("dashboard")}>Dashboard</button>
          <button className={"btn-outline " + (tab==="entrada" ? "bg-gray-100" : "")} onClick={()=>setTab("entrada")}>Entrada</button>
          <button className={"btn-outline " + (tab==="processo" ? "bg-gray-100" : "")} onClick={()=>setTab("processo")}>Processo</button>
          <button className={"btn-outline " + (tab==="vendedor" ? "bg-gray-100" : "")} onClick={()=>setTab("vendedor")}>Vendedor</button>
          <button className={"btn-outline " + (tab==="relatorios" ? "bg-gray-100" : "")} onClick={()=>setTab("relatorios")}>Relatórios</button>
        </div>
      </div>

      {tab==="dashboard" && <Dashboard/>}
      {tab==="entrada" && <Entrada/>}
      {tab==="processo" && <Processo/>}
      {tab==="vendedor" && (<><SaidaVendedor/><div className="h-4"></div><RetornoVendedor/></>)}
      {tab==="relatorios" && <Relatorios/>}

      <div className="text-xs opacity-60 text-center">Local-first (navegador). Use Exportar/Importar para backup. Construído com React + Vite + Tailwind.</div>
    </div>
  );
}
